#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private BPSessionRangeBoxes[] cacheBPSessionRangeBoxes;

		
		public BPSessionRangeBoxes BPSessionRangeBoxes()
		{
			return BPSessionRangeBoxes(Input);
		}


		
		public BPSessionRangeBoxes BPSessionRangeBoxes(ISeries<double> input)
		{
			if (cacheBPSessionRangeBoxes != null)
				for (int idx = 0; idx < cacheBPSessionRangeBoxes.Length; idx++)
					if ( cacheBPSessionRangeBoxes[idx].EqualsInput(input))
						return cacheBPSessionRangeBoxes[idx];
			return CacheIndicator<BPSessionRangeBoxes>(new BPSessionRangeBoxes(), input, ref cacheBPSessionRangeBoxes);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.BPSessionRangeBoxes BPSessionRangeBoxes()
		{
			return indicator.BPSessionRangeBoxes(Input);
		}


		
		public Indicators.BPSessionRangeBoxes BPSessionRangeBoxes(ISeries<double> input )
		{
			return indicator.BPSessionRangeBoxes(input);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.BPSessionRangeBoxes BPSessionRangeBoxes()
		{
			return indicator.BPSessionRangeBoxes(Input);
		}


		
		public Indicators.BPSessionRangeBoxes BPSessionRangeBoxes(ISeries<double> input )
		{
			return indicator.BPSessionRangeBoxes(input);
		}

	}
}

#endregion
